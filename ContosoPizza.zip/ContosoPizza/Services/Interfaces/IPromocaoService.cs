using ContosoPizza.DTOs.Promocao;
using ContosoPizza.Models;

namespace ContosoPizza.Services.Interfaces
{
    public interface IPromocaoService
    {
        Task<ServiceResponse<List<PromocaoResponseDto>>> GetPromocao();

        Task<ServiceResponse<List<PromocaoResponseDto>>> CreatePromocao(PromocaoCreateDto dto);

        Task<ServiceResponse<PromocaoResponseDto>> GetPromocaoById(int id);

        Task<ServiceResponse<PromocaoResponseDto>> UpdatePromocao(PromocaoUpdateDto dto);

        Task<ServiceResponse<string>> DeletePromocao(int id);
        
    }
}