using System.Diagnostics.Eventing.Reader;
using ContosoPizza.DataContext;
using ContosoPizza.DTOs.Pagamento;
using ContosoPizza.Enum;
using ContosoPizza.Models;
using ContosoPizza.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace ContosoPizza.Services.Implementations
{
    public class PagamentoService : IPagamentoService
    {
        private readonly ApplicationDbContext _context;

        public PagamentoService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<ServiceResponse<List<PagamentoResponseDto>>> GetPagamento()
        {
            ServiceResponse<List<PagamentoResponseDto>> serviceResponse = new ServiceResponse<List<PagamentoResponseDto>>();

            try
            {
                var pagante = await _context.Pagamento.ToListAsync();

                var PaganteDto = pagante.Select(p => new PagamentoResponseDto
                {
                    Id = p.Id,
                    PedidoId = p.PedidoId,
                    Tipo = p.Tipo,
                    Status = p.Status,

                    CodigoPix = p.Tipo == TipoEnum.Pix 
                        ? p.CodigoPix 
                        : null
                    
                }).ToList();

                serviceResponse.Dados = PaganteDto;
                
                if(PaganteDto.Count == 0)
                    serviceResponse.Mensagem = "Nenhum Dado Registrado.";
            }
            catch(Exception ex)
            {
                serviceResponse.Mensagem = ex.Message;
                serviceResponse.Sucesso = false;
            }

            return serviceResponse;
        }

        public async Task<ServiceResponse<string>> ConfirmarPagemento(int pedidoId)
        {
            ServiceResponse<string> serviceResponse = new ServiceResponse<string>();

            
            var pagamento = await _context.Pagamento
                .FirstOrDefaultAsync(p => p.PedidoId == pedidoId);

            if(pagamento == null)
            {
                serviceResponse.Sucesso = false;
                serviceResponse.Mensagem = "Pagamento não encontrado.";
            }
                
            else if(pagamento!.Status != Enum.StatusEnum.Pendente)
            {
                serviceResponse.Sucesso = false;
                serviceResponse.Mensagem = "Pagamento já processado ou cancelado.";
            }

            else
            {
                pagamento.Status = Enum.StatusEnum.Aprovado;

                await _context.SaveChangesAsync();

                serviceResponse.Sucesso = true;
                serviceResponse.Mensagem = "Pagamento confirmado";

                serviceResponse.Dados = $"Pago em: {pagamento.PagoEm}";
            }
        
            return serviceResponse;
        }
    }
}