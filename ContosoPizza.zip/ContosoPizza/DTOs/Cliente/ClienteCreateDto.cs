namespace ContosoPizza.DTOs.Cliente
{
        public class ClienteCreateDto
    {
        public string Nome { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }
}